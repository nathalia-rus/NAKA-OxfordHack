var symptoms = ['fever', 'cold', 'headache'];
var class_styles = ['primary', 'secondary', 'success', 'danger', 'warning', 'info', 'dark'];